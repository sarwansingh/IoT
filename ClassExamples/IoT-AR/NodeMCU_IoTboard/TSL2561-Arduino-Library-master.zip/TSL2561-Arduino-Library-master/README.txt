**DEPRECATED**
Please use new version of library:
https://github.com/adafruit/Adafruit_TSL2561

---------------------------
This is an Arduino library for the TSL2561 digital luminosity (light) sensors. 

Pick one up at http://www.adafruit.com/products/439

To download. click the DOWNLOADS button in the top right corner, rename the uncompressed folder TSL2561. Check that the TSL2561 folder contains TSL2561.cpp and TSL2561.h

Place the TSL2561 library folder your <arduinosketchfolder>/libraries/ folder. You may need to create the libraries subfolder if its your first library. Restart the IDE.
